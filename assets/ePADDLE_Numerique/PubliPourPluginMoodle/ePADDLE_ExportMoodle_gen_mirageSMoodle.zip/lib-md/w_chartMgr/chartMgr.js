var chartMgr = {
	init: function (){
		try {
			//scOnLoads[scOnLoads.length] = this;
		} catch(e){
			scCoLib.log("chartMgr.init error: "+e);
		}
	},
	onLoad : function(){
		try {
			//scCoLib.log("chartMgr.onLoad");
		} catch(e){
			scCoLib.log("chartMgr.onLoad error: "+e);
		}
	}
}
