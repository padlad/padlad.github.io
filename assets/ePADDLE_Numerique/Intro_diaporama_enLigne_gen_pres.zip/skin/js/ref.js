// Skin-specific Javascript code for the ref page.

