// Skin-specific Javascript code for slide pages.

