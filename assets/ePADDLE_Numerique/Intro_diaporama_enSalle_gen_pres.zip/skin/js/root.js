// Skin-specific Javascript code for the root page.

