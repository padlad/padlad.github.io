scServices.scormTopaze = scOnLoads[scOnLoads.length] = {
	fSteps : [],
	fIndexes : [],
	fStepsSeen : [],
	fGlobalIndexId : null,
	fGlobalIndexTp : null,
	fRoute : false,
	fOldTotalTime : 0,
	fMinScore : {},
	fMaxScore : {},

	onLoad : function(){
		if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
			var vApi = scServices.scorm2k4.getScorm2k4API();
			vApi.SetValue("cmi.session_time", "");
		}
	},

	register: function(pId,pType,pData){
		if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
			if(pType == "globalIndex") {this.fGlobalIndexId=pId;this.fGlobalIndexTp=pData;}
			if(pType == "index") this.fIndexes[pId]=pData;
			if(pType == "step") this.fSteps[pData]=pId;
			if(pType == "minPoints") this.fMinScore={'id':pId,'val':pData};
			if(pType == "maxPoints") this.fMaxScore={'id':pId,'val':pData};
			if(pId == null && pType == null && pData == null) this.fRoute=true;
		}
	},

	/*
	 * pFields : array
	 */
	LMSsetData : function(pFields,pVal){
		if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
			scServices.suspendDataStorage.setVal(["topaze"].concat(pFields), pVal);
		}
	},

	LMSsetScore : function(pRaw, pMin, pMax){
		if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
			var vApi = scServices.scorm2k4.getScorm2k4API();
			if (typeof pRaw != "undefined") vApi.SetValue("cmi.score.raw", pRaw);
			if (typeof pMin != "undefined") vApi.SetValue("cmi.score.min", pMin);
			if (typeof pMax != "undefined") vApi.SetValue("cmi.score.max", pMax);
		} 
	},

	sendData : function(){
		if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
			var vApi = scServices.scorm2k4.getScorm2k4API();
			vApi.SetValue("cmi.completion_status", "completed");
			scServices.exitModeStorage.terminate("");
		} 
	},

	loadSortKey: "1scormTopaze"
}

/*************** HACK ****************/
/**
 * @API SCORM2004topaze : Hack des fonctions de storage
 */ 
scServices.storage.activeStorage = function(pBoolean){
	if(!pBoolean) this.fIsActive = false;
	else {
		try {
			if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
				this.fStorage = scServices.scorm2k4.getScorm2k4API();
			} else {
				this.fIsActive = false;
			}
			this.fIsActive = true;
		}catch(e){
			this.fIsActive = false;
		}
	}
	return this.fIsActive;
}
scServices.storage.resetData = function(){
	if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
		var vApi = scServices.scorm2k4.getScorm2k4API();
		vApi.SetValue("cmi.completion_status", "incomplete");
		vApi.SetValue("cmi.suspend_data", "");
		vApi.SetValue("cmi.session_time", "");
		vApi.SetValue("cmi.location", "");
		vApi.SetValue("cmi.exit", "suspend");
	}
}
scServices.storage.onLoad = function(){
}
scServices.assmntMgr.reloadData = function(){
}
/**
 * @API SCORM2004topaze : surcharge pour supprimer le Commit à ce niveau et suppression de l'envoie du session time fait dans le commit
 */ 
scServices.exitModeStorage.terminate = function(pExitMode){
	this._done = true;
	this._exitMode = pExitMode;
	scServices.suspendDataStorage._Dirty = true;
};
/**
 * @API SCORM2004topaze : onunload renvoie suspend et incomplete si l'EDC est pas validée
 */ 
scServices.exitModeStorage.onUnload = function(){
	if(! this._done) {
		var vApi = scServices.scorm2k4.getScorm2k4API();
		vApi.SetValue("cmi.completion_status", "incomplete");
		this.terminate("suspend");
	}
}
/**
 * @API SCORM2004topaze : Pas d'utilisation de "interactions" : tout est écrit dans cmi.suspend_data
 */ 
scServices.assmntMgr.xConnect2k4 = function(){
	scServices.assmntMgr.xConnect12();
	this.commit = function(pLmsCommit, pLmsCommitParam){scServices.suspendDataStorage.commit(pLmsCommit, pLmsCommitParam);};
}
/**
 * @API SCORM2004topaze : Envoie du session time (tempas passé moins les pause) + pas de commit à interval régulier ni de commit sur les exos (le commit à lieu lors du unload) + scorm 1.2 renvoie null
 */ 
scServices.suspendDataStorage.commit = function(pLmsCommit, pLmsCommitParam) {
	if( ! this._Dirty) return;
	if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
		var vApi = scServices.scorm2k4.getScorm2k4API();
		// Hack : Commit et SetValue si pLmsCommit=true
		if(pLmsCommit) {
			vApi.SetValue("cmi.suspend_data", scServices.dataUtil.serialiseObjJs(this._Fields));
			scServices.scorm2k4.checkError(true);
			// Hack : on calcul le temps de session réel sans les temps de pause
			var vSteps = scServices.suspendDataStorage.getVal(["topaze","route"]) || scServices.suspendDataStorage.getVal(["topaze","steps"]), vStepTime = 0;
			if (vSteps && vSteps.length) {
				for (var i = 0; i < vSteps.length; i++) vStepTime += vSteps[i].t;
			}
			vApi.SetValue("cmi.session_time", scServices.exitModeStorage.serializeMsTime(vStepTime - scServices.scormTopaze.fOldTotalTime));
			scServices.scorm2k4.checkError(true);
			// Si pas de terminate alors on fait un commit (sinon le commit est fait dans le terminate)
			if(!scServices.exitModeStorage._done) {
				vApi.Commit(pLmsCommitParam);
				scServices.scorm2k4.checkError(true);
			}
			else {
				vApi.SetValue("cmi.exit",scServices.exitModeStorage._exitMode);
				vApi.Terminate("");
			}
			this._Dirty = false;
		}
	} else {
		return;
	}
}
/**
 * @API SCORM2004topaze : Convert json2obj sur _fields + suppression interval commit + scorm 1.2 renvoie null
 */ 
scServices.suspendDataStorage.onLoad = function(){
	var vApi;
	if(scServices.scorm2k4 && scServices.scorm2k4.isScorm2k4Active()) {
		vApi = scServices.scorm2k4.getScorm2k4API();
		try {
			this._Fields = scServices.dataUtil.deserialiseObjJs(vApi.GetValue("cmi.suspend_data"));
			scServices.scormTopaze.fStepsSeen = scServices.suspendDataStorage.getVal(["topaze","route"]) || scServices.suspendDataStorage.getVal(["topaze","steps"]) || [];
			// Stockage de l'ancien total time
			for (var i = 0; i < scServices.scormTopaze.fStepsSeen.length; i++) scServices.scormTopaze.fOldTotalTime += scServices.scormTopaze.fStepsSeen[i].t;
			scServices.scorm2k4.checkError();
		} catch(e){
			this._Fields = {};
			alert("SCORM 2004 : Echec à la récupération des précédentes données enregistrées.");
		}
	} else {
		return;
	}
}
/**
 * @API SCORM2004topaze : Suppression commit et terminate sur unload 
 */ 
scServices.scorm2k4.onUnload = function(){}
scServices.suspendDataStorage.onUnload = function(){}